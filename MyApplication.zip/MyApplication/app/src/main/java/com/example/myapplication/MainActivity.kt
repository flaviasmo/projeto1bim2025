package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.myapplication.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val lblAguardandoResultado = findViewById<TextView>(R.id.lblResultado)
        val iblclassificacaoImc = findViewById<TextView>(R.id.classificacaoImc)
        val btnCALCULARIMC = findViewById<Button>(R.id.btnCalcular)
        val edtaltura = findViewById<EditText>(R.id.edtAltura)
        val edtpeso = findViewById<EditText>(R.id.edtPeso)
        val btnLimpar = findViewById<Button>(R.id.btnLimpar) // Adicionado botão limpar

        btnCALCULARIMC.setOnClickListener {
            val altura = edtaltura.text.toString().toDoubleOrNull()
            val peso = edtpeso.text.toString().toDoubleOrNull()

            if (altura != null && peso != null && altura > 0 && peso > 0) {
                val imc = peso / (altura * altura)
                lblAguardandoResultado.text = "Seu IMC é: %.2f".format(imc)

                var classificacaoImc = ""
                if (imc < 18.5) {
                    classificacaoImc = "Abaixo do peso"
                } else if (imc in 18.5..24.9) {
                    classificacaoImc = "Peso normal"
                } else if (imc in 25.0..29.9) {
                    classificacaoImc = "Sobrepeso"
                } else if (imc in 30.0..34.9) {
                    classificacaoImc = "Obesidade I"
                } else if (imc in 35.0..39.9) {
                    classificacaoImc = "Obesidade II (severa)"
                } else {
                    classificacaoImc = "Obesidade III (mórbida)"
                }

                iblclassificacaoImc.text = "\nClassificação: " + classificacaoImc

            } else {
                lblAguardandoResultado.text = "Apresente valores válidos"
                iblclassificacaoImc.text = ""
            }
        }

        btnLimpar.setOnClickListener {
            edtaltura.text.clear()
            edtpeso.text.clear()
            lblAguardandoResultado.text = ""
            iblclassificacaoImc.text = ""
        }
    }
}